import datetime
def printTimeStamp(name):
 print('Автор програми: ' + name)
 print('Час компіляції: ' + str(datetime.datetime.now()))
x=input("Штучка")
y=input("Штукенція")
v=int(x)*75
g=int(y)*112
m=int(v)+int(g)
print(m,"г")
printTimeStamp("Псіна")